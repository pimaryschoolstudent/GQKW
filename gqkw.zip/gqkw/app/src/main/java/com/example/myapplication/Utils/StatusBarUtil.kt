package com.example.myapplication.Utils

/**
 * @author HuangJiaHeng
 * @date 2019/9/29.
 */
class StatusBarUtil {
    companion object{
        private var util:StatusBarUtil?=null
        @Synchronized
        get() {
            if (field==null){
                field = StatusBarUtil()
            }
            return field
        }
    }
}