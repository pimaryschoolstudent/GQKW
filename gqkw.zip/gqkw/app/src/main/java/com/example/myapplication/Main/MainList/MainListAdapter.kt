package com.example.myapplication.Main.MainList

import android.app.ProgressDialog.show
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable.RESTART
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.BaseViewHolder
import com.example.myapplication.Main.FileConnect.FileConnectActivity
import com.example.myapplication.Main.MainList.Model.ListData
import com.example.myapplication.R
import com.example.myapplication.Setting.SettingActivity
import com.example.myapplication.Utils.ToastUtils
import com.example.myapplication.Main.VideoConnect.VideoConnectiActivity

class MainListAdapter(data: ArrayList<ListData>,id:Int,context: Context): BaseQuickAdapter<ListData, BaseViewHolder>(id,data) {
    var context = context
    var connectOk =false
    override fun convert(helper:BaseViewHolder?, item: ListData?) {
        helper?.setText(R.id.item_tv,item?.title)
        var animationView=helper?.getView<LottieAnimationView>(R.id.item_lav)
        animationView?.setAnimation(item?.AnimationPath)
        helper?.itemView?.setOnClickListener {
            if (connectOk){
                when(helper?.layoutPosition){
                    0 -> Toast.makeText(context,"敬请期待",Toast.LENGTH_SHORT).show()
                    1 -> context.startActivity(Intent(context,FileConnectActivity::class.java))
                    2 -> context.startActivity(Intent(context, VideoConnectiActivity::class.java))
                    3 -> context.startActivity(Intent(context, SettingActivity::class.java))
                }
            }else{
                if (helper?.layoutPosition==3){
                    ToastUtils.get.showText("敬请期待")
                }else{
                    ToastUtils.get.showText("暂未连接至电脑")
                }
            }

        }
        if (helper?.layoutPosition==3){
            animationView?.repeatMode=RESTART
        }
        animationView?.playAnimation()
    }
    fun setConnect(boolean: Boolean){
        connectOk=true
    }
}