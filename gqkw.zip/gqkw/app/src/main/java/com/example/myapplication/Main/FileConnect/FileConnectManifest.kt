package com.example.myapplication.Main.FileConnect

interface FileConnectManifest {
    interface FileConnectView{
        fun ToolbarInit()
        fun initList()
        fun notifyListDataChange()
    }
    interface FileConnectPresenr{
        fun setAdapter()
        fun deleteAllFileData()
        fun registerReceiver()
        fun unregisterReceiver()
    }
}