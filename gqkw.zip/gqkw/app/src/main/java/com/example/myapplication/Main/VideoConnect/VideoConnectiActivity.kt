package com.example.myapplication.Main.VideoConnect

import com.example.myapplication.Base.BaseActivity
import com.example.myapplication.R

class VideoConnectiActivity (): BaseActivity() {
    override fun addTobBar(): Boolean {
        return true
    }

    override fun getLayoutId(): Int {
        return R.layout.video_connect
    }

    override fun Entrance() {

    }

}