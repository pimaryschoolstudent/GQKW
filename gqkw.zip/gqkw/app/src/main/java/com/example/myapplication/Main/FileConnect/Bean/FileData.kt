package com.example.myapplication.Main.FileConnect.Bean

/**
 * @author HuangJiaHeng
 * @date 2019/10/15.
 */
data class FileData (var file:String,var fileName:String,var fileSize:String)