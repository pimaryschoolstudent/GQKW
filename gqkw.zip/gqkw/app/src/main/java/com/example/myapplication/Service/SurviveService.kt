package com.example.myapplication.Service

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.example.myapplication.R

class SurviveService : Service() {


    override fun onBind(intent: Intent): IBinder? {
      return null
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        Log.i("survive","onTaskRemoved")
        super.onTaskRemoved(rootIntent)
    }

    override fun onCreate() {
        Thread(Runnable {
            while (true){
                Thread.sleep(1000)
                Log.i("survive","ONCreate#######")
            }
        }).start()
        super.onCreate()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        var builder = NotificationCompat.Builder(this, 12.toString())
            .setSmallIcon(R.drawable.ic_launcher_background)
            .setContentTitle("服务")
            .setContentText("服务运行")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        startForeground(1,  builder.build());

        Thread(Runnable {
            while (true){
                Thread.sleep(1000)
                Log.i("survive","ONStart")
            }
        }).start()


        return START_REDELIVER_INTENT
    }
}
