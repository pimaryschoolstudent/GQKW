package com.example.myapplication.Main.MainList.Model

data class ConnectEvent(var connectOk:Boolean,var message:String)