package com.example.myapplication.Base.Model

class Constract {
    companion object{
        const val TO_IP_CONNECT="ip"
        const val TO_IP_PORT="prot"
        var CONNECTION_STATUS=false
        const val MAINACTIVITY_OPENTYPE = "OPENTYPE"

    }
}