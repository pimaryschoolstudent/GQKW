package com.example.myapplication.Setting

import com.example.myapplication.Base.BaseActivity
import com.example.myapplication.R

class SettingActivity (): BaseActivity() {
    override fun addTobBar(): Boolean {
        return true
    }

    override fun getLayoutId(): Int {
        return R.layout.file_connect
    }

    override fun Entrance() {

    }

}