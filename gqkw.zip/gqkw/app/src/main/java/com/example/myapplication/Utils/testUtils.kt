package com.example.myapplication.Utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Log

import java.io.File
import java.io.FileOutputStream
import android.R
import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.annotation.RequiresApi





/**
 * @author HuangJiaHeng
 * @date 2019/9/9.
 */
class testUtils{
    companion object {
        fun saveBitmap(context: Context){
            var b = BitmapFactory.decodeResource(context.resources, com.example.myapplication.R.mipmap.ic_launcher)
            var File = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"share.png")
                File.delete()
                File.createNewFile()
            var bos = FileOutputStream(File)
            b.compress(Bitmap.CompressFormat.JPEG,100,bos)
            bos.flush()
            bos.close()
            var b1 = BitmapFactory.decodeFile(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath+"share.png")
            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            val f = File(File.absolutePath)
            val contentUri = Uri.fromFile(f)
            mediaScanIntent.data = contentUri
            context.sendBroadcast(mediaScanIntent)
//            MediaStore.Images.Media.insertImage(context.getContentResolver(), b1, "123" , "234")
            Log.i("bitmap1","\t"+Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath)
        }
//        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
//                View v = this.getWindow().getDecorView();
//                v.setSystemUiVisibility(View.GONE);
//              } else if (Build.VERSION.SDK_INT >= 19) {
//                //for new api versions.
//                View decorView = getWindow().getDecorView();
//                int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN;
//                decorView.setSystemUiVisibility(uiOptions);
//             
//              }
        fun AndroidWindow(context: Activity){
    //修改状态栏文字颜色 高亮
    context.window.decorView.setSystemUiVisibility( View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
    //修改状态栏文字颜色 透明
    //修改颜色
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {//5.0以上
                val window = context.getWindow()
//                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
//                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                context.window.setStatusBarColor(Color.RED)
                context.window.navigationBarColor= Color.RED
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                //使用SystemBarTint库使4.4版本状态栏变色，需要先将状态栏设置为透明
//                transparencyBar(activity)
//                val tintManager = cSystemBarTintManager(activity)
//                tintManager.setStatusBarTintEnabled(true)
//                tintManager.setStatusBarTintResource(colorId)
            }
        }
        fun getDisk(context: Activity){
            Log.e("Disk","DownloadCacheDirectory:"+Environment.getDownloadCacheDirectory())
            Log.e("Disk","DownloadCacheDirectory:"+Environment.getExternalStorageDirectory())
            Log.e("Disk","DownloadCacheDirectory:"+Environment.getDataDirectory())
            Log.e("Disk","DownloadCacheDirectory:"+Environment.getRootDirectory())
            Log.e("Disk","DownloadCacheDirectory:"+Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES))

            context.filesDir
        }
    }
}