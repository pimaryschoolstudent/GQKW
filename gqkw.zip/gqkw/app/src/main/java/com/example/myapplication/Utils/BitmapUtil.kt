package com.example.myapplication.Utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64


/**
 * @author HuangJiaHeng
 * @date 2019/10/15.
 */
object BitmapUtil {
    fun base64ToBitmap(base64:String):Bitmap{
        var byteArray = Base64.decode(base64,Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(byteArray,0,byteArray.size)
    }
}