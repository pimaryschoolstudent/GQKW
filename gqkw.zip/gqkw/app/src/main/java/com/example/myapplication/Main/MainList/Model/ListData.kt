package com.example.myapplication.Main.MainList.Model

data class ListData (var title:String,var AnimationPath:String)